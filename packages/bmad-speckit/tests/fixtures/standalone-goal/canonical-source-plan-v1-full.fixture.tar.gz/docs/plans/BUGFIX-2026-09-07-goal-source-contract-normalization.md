# BUGFIX: Goal Source Contract Normalization

Status: `frozen`

This document is the only execution tracker for the Goal Source Contract Normalization repair. It is not a Source Plan, Goal contract, Requirements authority, confirmation record, runtime receipt, or permission to execute the business work described by a fixture.

## 1. Authority And Frozen Inputs

### 1.1 Authority order

1. The current user instructions and repository `AGENTS.md` govern this repair.
2. This BUGFIX document freezes the accepted repair architecture and ordered acceptance gates.
3. `docs/plans/2026-09-05-standalone-goal-full-repair-execution-prompt.md` is historical RCA context only. Its former standalone authoring-Judge requirements are superseded and have no execution authority.
4. Existing schemas, code, tests, and generated surfaces are evidence to inspect; none may silently override the requirements frozen here.

### 1.2 Frozen real source

- Authorized source: `D:/Dev/micang-trader-016-dataservice-execution-v13-baseline-20260822/docs/plans/2026-09-04-dataservice-cold-hot-legacy-chain-source-plan.md`.
- Required byte length: `214296`.
- Required raw SHA256: `06f1c8f44fdfea09fb0f12832cd0a319c7938c79aac91aae48f44b54dc731d4a`.
- The source must decode as strict UTF-8 and must not be rewritten, normalized, shortened, reformatted, or augmented with IDs.
- The repository legacy fixture must be an exact byte copy of this source. A mismatch blocks fixture evidence until repaired by mechanical copy with before/after hash proof.
- The source describes business implementation semantics for compilation only. This repair must not execute its commands or modify its consumer repository.

### 1.3 Goal

Define and implement a versioned `standalone-source-plan/v1` producer contract, normalize all supported Goal-generation entries into a shared canonical requirement graph, aggregate source clauses under explicit semantic owners, and compile a sparse, source-faithful `GoalExecutionIR` without treating Markdown layout fragments as independent requirements.

The repaired system must support:

- canonical standalone Source Plans authored against the new template;
- the frozen unversioned real Source Plan through an explicit legacy compatibility adapter;
- confirmed Requirements sources used by the six-state Main Agent flow, proven with a separately derived and explicitly confirmed full fixture;
- confirmed Requirements sources used by req-trace direct and Main Agent compilation, proven with that same semantic fixture and each route's native authority records;
- deterministic tracing from every retained source span to its semantic owner or explicit non-semantic disposition.

### 1.4 Non-goals

- Do not modify the frozen consumer Source Plan or execute its business tasks.
- Do not restore or replace generation-time semantic validation with an external standalone authoring Judge. External Judge use remains confined to the post-execution Final Judge stage.
- The frozen legacy clauses `CONTRACT-008` and `CONTRACT-010` are mixed-semantics lines and MUST be partitioned into non-overlapping, gap-free byte subspans whose union exactly equals each original clause range. Only `goalJudgeDispatchCount=1` and the generation-time authoring semantic Judge prohibition are marked `superseded_by_user_authority`; every such subspan records the frozen source hash, exact-text hash, `supersededByRef`, and a non-executable provenance ref, and MUST NOT become an executable Goal obligation. `CONTRACT-010`'s retained `不得启动Goal` means the contract-generation transaction cannot create an execution dispatch, run lease, or execution artifact, not that a separately admitted Goal can never execute. `CONTRACT-008`'s `goalContractVersion=goal-execution-contract/v1` remains authoritative only when the public wire contract is unchanged; an identity, ownership, node-membership, or other public wire change requires an explicit new schema version plus a compatible v1 reader. Every retained subspan maps to canonical refs, and no part of this supersession removes the post-execution Final Judge gate.
- Do not impose `1048576` bytes as a semantic IR limit. Legitimate sparse authority may exceed that size.
- Do not weaken source coverage, typed-reference validation, closure, confirmation, readiness, or Final Judge gates.
- Do not make exact English or Chinese heading text, section order, or Markdown formatting the sole parser authority.
- Do not emit one Goal task per heading, list item, acceptance sentence, command, evidence row, or source span.
- Do not use production compiler output to define expected fixture semantics.
- Do not silently relabel a new wire representation as an older schema version.

### 1.5 Completion boundary

This repair is complete only when all six ordered stages in Section 6 pass, the canonical and frozen legacy fixtures satisfy the independent acceptance matrix, all three entry families converge on the shared semantic model, targeted local validation passes, and regular CI plus nightly-full are green on the same final `dev` commit. Merge and npm publication remain blocked until those conditions hold.

## 2. Root Cause And Target Architecture

### 2.1 Confirmed failure chain

The current standalone parser partitions Markdown into lexical blocks and clauses. Retained blocks are then materialized as source obligations, and an undeclared block receives a content-addressed `SRC-*` identifier. Although scope and provenance often retain the declared parent heading, the semantic projection still exposes many child PASS, FAIL, command, evidence, path, and condition blocks as independent rows.

This conflates four different concepts:

- physical source coverage;
- semantic requirements and boundaries;
- acceptance and proof declarations;
- executable work.

The old all-to-all constraint construction amplified those fragment-level rows by copying every obligation and atom reference into every PATH, CMD, ART, EVD, and STOP constraint. The resulting graph approached `O(obligation_count * constraint_count)` and produced the historical 34 MiB candidate. A smaller obligation count is not by itself correctness evidence; the repair must preserve all authorized semantics while eliminating false semantic nodes and unjustified edges.

### 2.2 Three-layer model

#### SourceDocumentGraph

`SourceDocumentGraph/v1` is the lossless source layer. It retains the exact source snapshot identity, every byte range, block, clause, table cell, code fence, declared identifier, heading ancestry, classification, condition, and derivation premise. Its coverage must account for every source byte and clause, including structure, background, examples, and historical evidence. A source block or clause ID is provenance, not an execution obligation.

#### CanonicalRequirementGraph

`CanonicalRequirementGraph/v1` is the shared semantic normalization boundary. It contains typed owner nodes and typed child registries with explicit relations. Every semantic node must have one stable canonical ID, source spans, a role, modality, polarity, applicability, and justified owner/binding relations. Multiple non-contiguous source spans may contribute to one requirement block. One source span may contribute multiple typed clauses only when the split and ownership are explicit and losslessly traceable.

The graph must distinguish:

- implementation requirements and non-functional requirements;
- prohibitions and out-of-scope boundaries;
- executable tasks and task atoms;
- acceptance scenarios and expected PASS/FAIL/BLOCKED states;
- commands, evidence contracts, artifacts, paths, dependencies, and stop conditions;
- background, examples, definitions, metadata, and historical observations.

#### GoalExecutionIR

`GoalExecutionIR` consumes `CanonicalRequirementGraph/v1` or an explicitly versioned equivalent adapter projection. It must not infer semantic ownership directly from Markdown layout. Goal tasks are generated only from action obligations or approved task atoms. Acceptance, command, evidence, path, dependency, and provenance nodes remain typed relations or registries; they do not manufacture tasks.

### 2.3 Canonical identity grammar

Canonical producer IDs use uppercase ASCII tokens and hyphens:

- `REQ-<DOMAIN>-NNN` for functional or behavioral requirements.
- `NFR-<DOMAIN>-NNN` for non-functional requirements.
- `NEG-<DOMAIN>-NNN` for explicit prohibitions.
- `OUT-<DOMAIN>-NNN` for excluded implementation scope.
- `TASK-<DOMAIN>-NNN` for declared work units.
- `AC-<DOMAIN>-NNN` for acceptance criteria and `AC-<DOMAIN>-NNN-SNN` for their scenarios.
- `CMD-<DOMAIN>-NNN` for validation commands.
- `EVD-<DOMAIN>-NNN` for evidence contracts.
- `ART-<DOMAIN>-NNN` for produced artifacts.
- `PATH-<DOMAIN>-NNN` for path declarations.
- `DEP-<DOMAIN>-NNN` for explicit dependency declarations.
- `STOP-<DOMAIN>-NNN` for stop conditions.

`MUST`, `SHOULD`, and `MAY` are modality values, not identifier prefixes. `NOT DONE` is the human projection of an `OUT-*` boundary, not an ID. `SRC-*`, `SPAN-*`, `source-block-*`, and `clause-*` are internal source identities and must not appear as top-level business requirements, Goal tasks, acceptance IDs, commands, or evidence IDs.

`<DOMAIN>` matches `[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)*`; `NNN` and `SNN` are zero-padded decimal sequences. Canonical producer IDs are authored identities and must not be renumbered when an unrelated node is inserted. Compatibility-only synthesized identities use a distinct `AUTO-<12 uppercase hexadecimal characters>` suffix and are stable for the frozen source snapshot and semantic owner.

Legacy declared IDs such as `FIX-*`, `WORK-*`, `FR-*`, and existing `AC-*` remain exact source aliases. An alias never changes the canonical node's role or source span and never permits two canonical owners for the same semantic block.

### 2.4 Requirement-block aggregation

A canonical requirement block contains at least:

- canonical ID, source aliases, title, statement, role, modality, and polarity;
- applicability and conditions;
- source span and clause references;
- owner or parent relations when it is a child node;
- TASK, AC, PATH, CMD, EVD, ART, DEP, NEG, OUT, and STOP references as applicable;
- an observable required outcome or an explicit pure-boundary disposition.

Ownership resolution is ordered:

1. explicit `ownerRef` or `requirementRefs` in a versioned source;
2. a declared requirement, task, or acceptance owner block;
3. deterministic legacy heading, list, or table inheritance;
4. fail closed when no unique owner can be established.

Adjacency alone is not authority. A PASS, FAIL, BLOCKED, command, evidence, path, or dependency child without a unique owner fails with `source_semantic_owner_missing`. Duplicate or conflicting owners fail with a located ambiguity. The compiler must not repair either condition by creating a synthetic top-level requirement.

For the frozen source, the PASS sentence under legacy `AC-20-S03` is an expected outcome of that acceptance scenario. It remains source-traceable, but it must not become a visible `SRC-*` requirement. Its full Given/When/Then, PASS/FAIL/BLOCKED, command, evidence, and owning requirement context must be rendered together.

### 2.5 Purpose compatibility

A canonical Source Plan declares its intended consumer and implementation purpose in metadata. Normative content may constrain business implementation and compiler behavior, but a clause that denies the authorized production of its Goal contract is a purpose contradiction. The pre-semantic gate must reject it as `source_plan_purpose_conflict` with source ID, lines, byte span, excerpt, conflicting target, and repair hint.

Legitimate prohibitions remain authoritative, including forbidden write paths, forbidden test bypasses, prohibited architecture alternatives, conditional non-execution, and the ban on generation-time external Judge use. Purpose validation must not erase or weaken those boundaries.

## 3. Canonical Source Plan Contract

### 3.1 Canonical and installed assets

The repository canonical assets are:

- `_bmad/shared/goal-contract/standalone-source-plan-template.md`;
- `_bmad/shared/goal-contract/standalone-source-plan-profile.json`;
- `_bmad/shared/goal-contract/standalone-source-plan-profile.schema.json`;
- `_bmad/shared/goal-contract/canonical-requirement-graph.schema.json`;
- `_bmad/shared/goal-contract/standalone-source-plan-lint-result.schema.json`.

Installed copies are generated projections at `_bmad/skills/goal-execution-contract-generator/references/standalone-source-plan-template.md` and `_bmad/skills/goal-execution-contract-generator/references/standalone-source-plan-profile.json`. Tests must prove canonical/projection byte equality or an explicitly declared allowed-difference rule, profile hash consistency, package inclusion, and Codex/Claude Code/Cursor resolution. Generated projections must not become independent edit sources.

### 3.2 Versioned source metadata

A canonical source declares:

- `sourcePlanVersion: standalone-source-plan/v1`;
- a stable `sourcePlanId`;
- `intendedConsumer: goal-execution-contract-generator`;
- `purpose: implementation_execution`;
- source language and repository identity when known;
- declared ID domains and any legacy alias namespace;
- whether global declarations are permitted and how they are identified.

This metadata describes the source contract and is not itself an implementation requirement. The standalone profile must not require `implementationConfirmation`. Confirmed Requirements routes retain their own inline confirmation and governed-record requirements outside this source profile.

### 3.3 Required semantic node fields

Every `REQ`, `NFR`, `NEG`, and `OUT` owner declares its canonical ID, one deterministic statement, modality, polarity, applicability, source scope, and typed references. An executable requirement also declares or references a required outcome. A pure boundary is complete when its prohibited or excluded scope is deterministic; it must not invent an action task.

Every `TASK` declares owner requirement refs, execution class, owned production paths, steps or atom refs, dependencies, acceptance refs, command refs, and evidence refs. Aggregate-only tasks must explicitly declare `ownedProductionPaths: none`, their allowed aggregate phase, and their aggregate validation commands.

Every `AC` declares at least one requirement or task owner and a deterministic predicate. Scenario-shaped acceptance uses Given, When, Then, PASS, FAIL, and BLOCKED fields as child values of one acceptance node. Those labels never create independent semantic identities.

Every `CMD`, `EVD`, `ART`, `PATH`, `DEP`, and `STOP` declares a canonical ID, type-specific value, owner refs, and applicable requirement/task/acceptance refs. A command also declares working-directory assumptions and pass criteria. Evidence declares its producer, expected fields or assertion, and consuming acceptance gate. A global declaration explicitly uses `scope: global` and supplies source authority for every allowed broad relation.

### 3.4 Lint and generation preflight

Add the first-class CLI entry `bmad-speckit goal-contract lint-source --entry standalone_goal_contract --source <path> --json`. Its result schema is `StandaloneSourcePlanLintResult/v1`. `goal-contract generate --entry standalone_goal_contract` must invoke the same validator after snapshot identity is frozen and before semantic obligation or constraint allocation.

The validator must reject at least:

- unsupported or falsely labeled source versions;
- invalid or duplicate canonical IDs;
- dangling refs, type-invalid refs, and conflicting aliases;
- orphan acceptance, command, evidence, artifact, path, dependency, and stop nodes;
- ambiguous legacy ownership;
- purpose contradictions;
- unbounded or unauthorized global fan-out;
- unresolved executable semantics and nondeterministic required outcomes;
- a child source identity projected as a top-level canonical requirement;
- metadata or examples presented as current execution authority.

Errors are structured and bounded. Each located error carries a failure class, source artifact ID, source snapshot hash, line/byte range, offending ID or field, excerpt hash, and repair hint. Diagnostics may include a short bounded excerpt but must not print the full source or graph.

### 3.5 Flexible syntax, strict semantics

The canonical template defines the preferred producer surface. The profile defines semantic fields, ID rules, node types, relation types, required bindings, and validation rules. It must not require one natural-language heading spelling or a single section order when explicit typed declarations make the semantics equivalent.

Compatibility parsing may recognize equivalent Chinese/English labels, Markdown tables, declared headings, and legacy list structures. Such recognition must normalize into the same canonical fields and preserve exact source provenance. Heuristic recognition cannot override explicit typed declarations, create an owner from proximity alone, or convert an unresolved source into an apparently valid canonical graph.

### 3.6 Shared entry normalization

The following adapters must produce or validate the same canonical node and relation semantics before Goal execution compilation, then invoke the single shared `compileGoalExecutionIR` implementation in `packages/bmad-speckit/src/utils/goal-contract/control-plane/goal-execution-ir.ts`. An entry-specific parallel semantic compiler or copied IR constructor is forbidden:

- standalone Source Plan snapshot and legacy compatibility adapter;
- six-state requirements-backed semantic IR after valid requirement confirmation, architecture confirmation, and implementation readiness;
- req-trace direct confirmed-source compilation;
- req-trace Main Agent compilation through its governed record path.

Entry-specific source lineage, confirmation, readiness, and authority hashes remain distinct. Semantic parity means equivalent requirement roles, polarity, applicability, conditions, boundaries, dependencies, commands, evidence, and owner relations; it does not require unrelated source hashes or governed-record IDs to be equal.

The lint boundary has two layers. `lintStandaloneSourcePlan` owns only the canonical standalone Markdown/fenced-YAML syntax and provenance parse. A shared `lintCanonicalRequirementGraph` owns ID grammar, owner/reference/alias integrity, applicability, purpose, global-scope authority, and sparse relation rules. Six-state and req-trace MUST NOT feed `implementationConfirmation` text into the standalone syntax parser; after their native confirmation/readiness admission succeeds, a deterministic confirmed-source adapter MUST produce `CanonicalRequirementGraph/v1` and obtain a passing shared graph-lint receipt before any Goal execution allocation. A document-syntax PASS cannot substitute for graph lint, and a confirmed-source admission PASS cannot bypass it.

All accepted entries then invoke one shared compiler path that returns the canonical graph, canonical semantic hash, `GoalExecutionIR`, closure, and Goal projection. The canonical semantic hash for semantically equivalent fixtures MUST match across entries. Full IR, closure, publication, and authority-envelope hashes remain entry-bound because they include distinct profile, lineage, confirmation, and technical-authority identities; parity tests compare an explicitly normalized semantic projection rather than deleting those identities or falsely asserting byte equality.

## 4. Compatibility And Versioning

### 4.1 Fixture classes

The test portfolio keeps four distinct source classes:

1. `canonical-positive`: sources that conform to `standalone-source-plan/v1` and exercise the preferred producer path.
2. `legacy-compatibility`: the exact frozen unversioned real Source Plan, normalized through the explicit legacy adapter without changing its bytes.
3. `confirmed-derived-parity`: a separate Requirements source derived from the reviewed canonical full graph, carrying a valid native `implementationConfirmation` and governed confirmation receipt for six-state and req-trace tests.
4. `negative`: versioned or legacy mutations that contain invalid identities, ownership, references, applicability, purpose, or graph density.

The legacy fixture is not a template example. The canonical minimal fixture proves grammar and type coverage. The canonical full fixture proves that the real authorized semantics can be represented completely under the new contract. None may replace another.

### 4.2 Legacy normalization

An input without `sourcePlanVersion` is identified as `legacy/unversioned`. The adapter may derive ownership only from deterministic source evidence such as declared `FIX-*`, `WORK-*`, `AC-*`, explicit reference fields, heading ancestry, list inheritance, and table relations. It must preserve each original ID as a source alias and preserve exact span provenance.

Legacy normalization must aggregate child fields under their unique owner. It must not emit a child `SRC-*` row as a top-level semantic requirement merely because the child occupies its own Markdown list item. A genuinely standalone normative paragraph may receive a stable compatibility canonical ID only when its complete subject, action or boundary, applicability, and outcome are deterministic and it is not a typed child declaration.

Ambiguous legacy semantics fail closed. Compatibility does not authorize silent omission, default all-to-all relations, invented commands, fabricated evidence, inferred implementation work for pure boundaries, or weakening of purpose and confirmation rules.

### 4.3 Canonical full derivation

`canonical-source-plan-v1-full.md` is independently derived from the frozen real source. During derivation, each completed semantic section is accompanied by a non-authoritative working mapping ledger so the next section cannot start with unaccounted source spans. Phase 5 promotes the complete, reviewed ledger into the derivation manifest that becomes the mapping authority. Production extractor, canonical graph compiler, GoalExecutionIR, Markdown projection, or Goal contract output may be compared as actual results but must not generate the working ledger, expected manifest, or expected graph.

The derivation manifest accounts for every source span and records its exact hash, disposition, canonical refs, and reason. Non-semantic spans remain covered with explicit structure, background, example, metadata, or historical dispositions. Every normative span maps to one or more canonical nodes, and every canonical node maps back to source authority.

The canonical full source is self-contained. It may record the frozen legacy source identity but must not require the compiler to reopen the legacy file to understand requirements. Any true source ambiguity or purpose contradiction requires a source-authorized amendment; canonicalization cannot silently correct it.

### 4.4 Confirmed-source parity derivation

Phase 5 creates `packages/bmad-speckit/tests/fixtures/standalone-goal/canonical-source-plan-v1-full.confirmed-requirements.md` and `packages/bmad-speckit/tests/fixtures/standalone-goal/canonical-source-plan-v1-full.confirmation-receipt.json`. The Requirements source is derived from the reviewed manifest and expected graph, remains semantically equivalent to canonical full, and is authored through `requirements-contract-authoring`; it is not produced by the production extractor or Goal compiler.

The inline `implementationConfirmation` and receipt must bind the exact Requirements source, canonical source, manifest, and expected-graph hashes and must pass the native confirmation validators used by six-state and req-trace. `status: user_confirmed` may be written only after the user explicitly confirms the exact derived fixture hash and review view. Until that event exists, the fixture remains draft and Phase 5 is blocked; test code, a model assertion, or this BUGFIX document cannot synthesize confirmation.

### 4.5 Wire compatibility

Use the smallest schema change that preserves semantics and consumer safety. Additive fields may remain in an existing schema only when existing validators and readers explicitly permit them without semantic reinterpretation. Any change to identity meaning, required ownership, node membership, decoding, or authority hashing requires a new schema version and same-version reader support.

Older supported authorities remain readable only under their declared semantics. Unsupported typed graphs, unknown node kinds, missing owners, dangling aliases, cyclic ownership, unreachable nodes, or expansion overflow fail closed. New data must never be stripped and relabeled as an old authority.

### 4.6 Sparse relations and resource behavior

Constraint relations are derived from explicit typed bindings and applicability. PATH, CMD, EVD, ART, DEP, and STOP nodes reference only their actual owners and applicable requirements/tasks/acceptance nodes. Broad scope is legal only when an explicit global declaration supplies source authority.

Pre-allocation checks reject proven non-global fan-out, superlinear edge construction, illegal cycles, and configured local allocation exhaustion. Serialized UTF-8 sizes remain diagnostics unless an active adapter or provider declares a verified capacity. `1048576` is not a standalone semantic limit.

Any compact or dictionary representation requires an explicit version, deterministic decoder, reachability checks, expanded-byte/hash verification, and round-trip semantic equivalence. Compression, omission, truncation, summaries, or unreadable local-path handoffs cannot substitute for authority preservation.

### 4.7 Judge boundary

Pure standalone generation selects no external provider, creates no Judge transport, and emits no authoring Judge request, response, aggregate, or compatibility EffectivePass. The Source Oracle and deterministic semantic validator are the generation-time semantic gates. Post-execution Final Judge remains mandatory in the execution lifecycle and is outside Source Plan normalization.

Requirements-backed routes retain only the Judges already required by their native governed lifecycle. Shared normalization must not add a new goal-wide authoring Judge or remove an existing confirmation, architecture, readiness, audit, or delivery gate.

## 5. Acceptance Matrix

Every gate below is mandatory. Counts and byte sizes are reported as observations, not substituted for semantic correctness. New mandatory tests may not skip, xfail, or silently fall back to a smaller fixture.

| Gate | Required proof |
| --- | --- |
| Frozen source identity | External authority and repository legacy fixture both have `214296` bytes, raw SHA256 `06f1c8f44fdfea09fb0f12832cd0a319c7938c79aac91aae48f44b54dc731d4a`, and strict UTF-8 decoding. |
| Canonical assets | Shared template/profile validate, project to the installed skill, are included in package/install manifests, and resolve on Codex, Claude Code, and Cursor surfaces. |
| Canonical minimal source | Every declared node kind and legal relation is exercised; lint and standalone generation pass; all refs resolve; no semantic top-level ID uses `SRC-*`. |
| Negative source portfolio | Duplicate IDs, dangling refs, wrong-type refs, orphan typed children, conflicting aliases, ambiguous owners, illegal global fan-out, purpose conflict, and nondeterministic execution semantics fail with located structured diagnostics. |
| Full canonical derivation | The independently reviewed full source is self-contained, valid v1, and accounts for every authoritative legacy semantic without executing business commands. |
| Independent proof assets | Derivation manifest and expected graph are not derived from production actual output; integrity receipt binds all input and expected hashes and records `unmappedNormativeSpans: 0` and `orphanSemanticNodes: 0`. |
| Confirmed parity fixture | The separate full-derived Requirements fixture is semantically equivalent to canonical full, has an exact user-confirmed hash-bound receipt, and passes native six-state and req-trace confirmation/admission checks without weakening or fabricating confirmation. |
| Lossless source graph | Every byte and clause is covered by SourceDocumentGraph; structure/background/example/metadata/historical content has explicit non-executable disposition. |
| Requirement aggregation | Child PASS/FAIL/BLOCKED/CMD/EVD/PATH/DEP rows remain source-traceable but are grouped under their unique semantic owner and do not become top-level requirements or tasks. |
| Real AC regression | The frozen `AC-20-S03` PASS sentence is present exactly once as the scenario's expected outcome with its full owner, command, evidence, condition, and source-span chain. |
| Canonical identities | IDs satisfy the declared grammar; aliases preserve legacy IDs; modality and NOT DONE are not encoded as fake ID kinds; collisions and alias cycles are absent. |
| Typed ownership | Every AC/CMD/EVD/ART/PATH/DEP/STOP has valid type-compatible owner and applicability refs. Pure boundaries do not manufacture implementation tasks or proof commands. |
| Conditional semantics | Conditional obligations retain unevaluated predicates and trace coverage but do not become unconditional actions. Applicable actions alone drive task execution membership. |
| Purpose compatibility | Self-denial of authorized Goal contract generation fails as `source_plan_purpose_conflict`; legitimate business and governance prohibitions remain unchanged. |
| Legacy compatibility | The exact unversioned real source compiles through the legacy adapter without source edits, fake IDs, fixture exemptions, or semantic weakening. |
| Frozen v1 reader compatibility | A frozen `goal-execution-contract/v1` positive fixture decodes, round-trips, and preserves its closure, projection, and authority hashes through the compatibility reader; public wire changes use a new schema version rather than mutating v1. |
| Semantic equivalence | Legacy full and canonical full normalize to equivalent roles, polarity, conditions, boundaries, dependencies, command/evidence relations, and required outcomes; lineage/hash differences are explicitly excluded from equivalence. |
| Three-entry parity | standalone, six-state requirements-backed, req-trace direct, and req-trace Main Agent paths each pass entry syntax/admission checks, adapt to `CanonicalRequirementGraph/v1`, pass the same graph lint, call the same IR/closure/projection compiler, and produce the same normalized semantic hash while retaining distinct native confirmation/readiness/lineage envelope hashes. |
| Sparse relations | Each constraint references only actual applicable owners or a source-authorized global group; no non-global all-to-all obligation, atom, or premise arrays exist. |
| Scale | Fixed-density N/2N/4N fixtures show edge and serialized-size growth proportional to declared nodes and relations rather than `N*C`; real global/shared relations remain correct. |
| Size semantics | Candidate and request UTF-8 bytes are measured separately; a legitimate sparse candidate is not rejected solely for crossing 1 MiB; verified adapter/provider limits apply only at that transport. |
| IR integrity | GoalExecutionIR obligations, aliases, tasks, trace slices, commands, evidence contracts, artifacts, dependencies, closure, authority, and Markdown projection are hash-consistent and source-reachable. |
| IR lineage closure | Every GoalExecutionIR node and relation is reversibly linked to a canonical graph node/relation and its SourceDocumentGraph span; each entry also records the originating standalone snapshot or confirmed Requirements semantic IR/authority hash. Missing, mismatched, stale, or cross-source lineage fails closed before publication. |
| No generation Judge | Standalone pure generation reports zero external Judge dispatch and emits no generation-time Judge artifacts; Final Judge code remains only in the post-execution lifecycle. |
| Lifecycle separation | Generation-only tests prove zero execution dispatch, run lease, or execution artifact; a separately admitted execution reaches exactly the post-execution Final Judge route while generation-time authoring Judge dispatch remains zero. |
| Failure atomicity | Lint, normalization, graph, schema, or publication failure leaves no partial active authority and cannot reuse stale hashes as proof. |
| Installed production path | Packed/installed CLI exercises the real template, linter, canonical fixtures, legacy fixture, and affected entries without source-tree shortcuts or consumer-root scripts. |
| Encoding and scope | Encoding scan reports zero findings; staged files equal the approved repair paths; unrelated drafts, backups, artifacts, and user files remain unstaged. |
| Delivery | Regular CI and nightly-full pass on the same final `dev` SHA before merge; npm dry-run precedes Trusted Publishing; registry, dist-tag, tag, release, assets, commit, and provenance are verified after publication. |

### 5.1 Independent expected-data rules

- Establish expected semantic ownership and mappings before using repaired production output as actual evidence.
- Review source evidence for every expected correction. Never change expected solely to make a test pass.
- Store source and expected hashes in the same integrity receipt and invalidate the receipt when either changes.
- Keep raw source coverage assertions independent from semantic-node count and relation-density assertions.
- Verify aliases and semantic equivalence through canonical fields, not rendered prose or array order alone.

### 5.2 Required mutation tests

Mutation tests must reject at least:

- promoting an AC child PASS sentence to an independent requirement;
- deleting a normative source span from an owner aggregate;
- binding a command or evidence row to an unrelated task;
- flipping required and forbidden polarity;
- erasing or unconditionally activating a condition;
- replacing a dependency with source adjacency;
- marking a non-global constraint applicable to every obligation;
- inserting a universal must-link/co-execution group;
- changing a legacy alias target without changing source authority;
- removing, mutating, or cross-wiring a SourceDocumentGraph span, CanonicalRequirementGraph ref, or originating Requirements semantic-IR lineage from GoalExecutionIR;
- relabeling a v2/new graph as an older wire version;
- restoring generation-time external Judge artifacts;
- using a candidate-byte threshold to drop or summarize legitimate authority.

### 5.3 Evidence strength

Automated regression proves deterministic compiler behavior but does not prove human confirmation or online Judge activity. Installed integration proves package and host resolution but not business execution. Governed acceptance proves the corresponding controlled route only when its source, confirmation, record, compiler, package, and run identities are current and hash-consistent.

No fixture compiler test may claim that the trading-system work was executed. No coverage receipt, exit code, mock response, or historical run may be presented as stronger evidence than it provides.

## 6. Ordered Execution And Evidence

The phases are strictly ordered. A phase may start only after its predecessor's artifacts are reread, deterministic checks pass, required audit closes, encoding integrity passes when applicable, and the evidence checkpoint is persisted.

### Phase 1: freeze this BUGFIX authority

Inputs: current user instructions, repository rules, historical RCA prompt, frozen real-source identity, current code and tests.

Outputs:

- this BUGFIX document;
- large-document-writer receipts for init, all chunks, assembly, validation, promotion, and cleanup;
- one latest-hash three-perspective audit binding and receipts;
- an issue disposition table with no unresolved Blocker or Major;
- encoding scan and target SHA256.

Gate: the document contains the target architecture, canonical identity rules, aggregation and purpose rules, compatibility/versioning policy, acceptance matrix, modification paths, non-goals, ordered phases, and evidence policy. The document is not passed into Goal contract compilation.

### Phase 2: establish the Source Plan contract

Create canonical shared template/profile assets, installed skill projections, deterministic verification, and the Source Plan lint command. Update canonical skills to describe the new producer path and three-entry normalization boundary. Do not directly edit generated `.codex`, `.claude`, `.cursor`, or dist files as sources; regenerate through repository-owned commands.

The CLI syntax is `bmad-speckit goal-contract lint-source --entry standalone_goal_contract --source <path> --json`, and the result must validate as `StandaloneSourcePlanLintResult/v1`. This phase may implement only parsing and validation needed to prove the source contract; it must not use later fixture expected data as production logic.

Gate: template/profile/schema checks, projection equality, package manifest discovery, focused lint tests, skill contract tests, and encoding integrity pass. No fixture from a later phase is used to define the contract.

### Phase 3: establish minimal positive and negative fixtures

Create `packages/bmad-speckit/tests/fixtures/standalone-goal/canonical-source-plan-v1-minimal.md` with every node and legal relation type. Store focused negative mutations below `packages/bmad-speckit/tests/fixtures/standalone-goal/invalid-v1/` for identity, refs, ownership, purpose, applicability, and global fan-out. Validate expected source/profile semantics with an independent fixture validator, then compile the positive fixture through the production standalone generation entry. If that production compile fails because versioned-source dispatch promised by Phase 2 is incomplete, reopen Phase 2, repair that dispatch, and rerun its gate before re-entering Phase 3; do not skip forward to Phase 4 or Phase 6.

Gate: the minimal positive fixture passes profile and Source Plan lint, reference integrity, ID grammar, owner validation, and production standalone compilation; its independently authored node/reference inventory is complete; every negative fixture fails with its exact expected failure class and no partial authority; and neither the canonical graph nor Goal projection contains a top-level semantic `SRC-*`. Full legacy normalization, full-derived parity, and remaining compiler regressions are established as Phase 6 RED evidence only after Phase 5 freezes their independent expected data.

### Phase 4: derive the canonical full source

Use only the frozen real Source Plan and an independent reviewed mapping process to create `packages/bmad-speckit/tests/fixtures/standalone-goal/canonical-source-plan-v1-full.md`. Preserve legacy IDs as aliases, aggregate complete requirement and acceptance blocks, and keep the source self-contained. Use large-document-writer with section-level hash receipts. For each completed section, persist a non-authoritative working mapping ledger that accounts for the consumed legacy spans; do not label that ledger as the final derivation manifest or confirmed evidence.

Gate: canonical full lint passes; every completed canonical section has a hash-bound working-ledger entry and no consumed legacy normative span is unaccounted; every canonical node has provisional source authority; unresolved ambiguities and purpose conflicts are zero or stop the phase with exact source evidence. Complete cross-section coverage and confirmation are frozen only in Phase 5.

### Phase 5: freeze independent proof assets

Create below `packages/bmad-speckit/tests/fixtures/standalone-goal/`:

- `canonical-source-plan-v1-full.derivation-manifest.json`;
- `canonical-source-plan-v1-full.expected-graph.json`;
- `canonical-source-plan-v1-full.integrity.json`.

The expected graph is authored from the reviewed manifest, never copied from production actual output. Run independent completeness, duplicate, reference, span/hash, owner, and equivalence checks before freezing the receipt.

Derive the separate full Requirements parity fixture and its confirmation review view from the reviewed manifest and expected graph. Request explicit user confirmation only after publishing its exact hash and review evidence; never infer confirmation from authorization to perform this repair.

The fixture review authority is `StandaloneSourcePlanFixtureReview/v1`: a latest-hash, three-perspective read-only review of source coverage, semantic mapping, and executable verification, followed by main-session disposition and deterministic integrity checks. Its receipt binds the legacy source, canonical source, manifest, and expected graph hashes. `reviewStatus: confirmed` means that this fixture-review protocol passed; it is not `implementationConfirmation`, user confirmation of business execution, or permission to execute the consumer plan.

Gate: all proof hashes are current; `unmappedNormativeSpans` is zero; `orphanSemanticNodes` is zero; fixture review status is confirmed; the separately derived Requirements fixture has a valid explicit user-confirmation receipt and passes native six-state/req-trace confirmation gates; tamper tests fail closed.

### Phase 6: TDD compiler implementation

Add failing regression tests first, then implement SourceDocumentGraph separation, owner-aware CanonicalRequirementGraph aggregation, shared entry adapters, purpose/owner diagnostics, sparse constraint relations, canonical aliases, projection grouping, and version-safe readers. Every standalone, six-state, req-trace direct, and req-trace Main Agent adapter must emit a passing shared graph-lint receipt and call the same `compileGoalExecutionIR`, closure compiler, and Goal projection; spy/identity tests must fail if an entry bypasses a shared stage or reconstructs a parallel semantic IR. Preserve existing valid gates and remove obsolete generation-Judge expectations.

Gate: the full matrix in Section 5 passes through source, package, installed runtime, and all-entry paths. Use actual source/dist build order. A test failure is fixed only when its root cause is within this repair; unrelated failures are recorded without weakening this scope.

### 6.1 Expected modification surface

Approved paths are limited to:

- `docs/plans/BUGFIX-2026-09-07-goal-source-contract-normalization.md`;
- `_bmad/shared/goal-contract/` canonical assets, profile/graph/result schemas, and validators;
- `_bmad/skills/goal-execution-contract-generator/`;
- affected `_bmad/skills/req-trace-matrix-prompt-generator/` and `_bmad/skills/bmad-speckit/` contract text or generated projections;
- `packages/bmad-speckit/src/commands/goal-contract.ts` and a directly owned Source Plan lint command/module;
- `packages/bmad-speckit/src/utils/goal-contract/` source parsing, canonical graph, adapters, IR, constraints, projection, closure, schemas, and owned helpers;
- directly related package/acceptance tests and `packages/bmad-speckit/tests/fixtures/standalone-goal/` fixtures;
- repository-owned install/package manifests only when required to ship the new assets.

Dependency changes, root configuration, CI workflow edits, database changes, consumer-repository changes, and unrelated refactors are outside scope unless repository evidence proves they are indispensable and the scope expansion is reported before editing.

### 6.2 Validation sequence

Local validation uses focused, bounded commands first:

1. new Source Plan lint, canonical graph, aggregation, identity, alias, purpose, and sparse-relation tests;
2. existing source-obligation, normative-block, execution-semantics, canonical-control-plane, implementation-proof, coverage, partition, sequence, and requirements-backed adapter tests selected by the affected call graph;
3. skill/profile/install-surface tests;
4. TypeScript typecheck, lint, required build, encoding integrity, and `git diff --check`;
5. package dry-run/install verification without publishing.

Full matrices, Windows command-length coverage, installed host matrices, and other long suites run only in remote PR CI. Full logs are persisted; session output reports bounded summaries, counts, hashes, failure classes, and evidence paths.

The evidence root is `.artifacts/goal-source-contract-normalization/<phase>/<run-id>/`. Each checkpoint records command, working directory, exit code, test/pass/fail/skip counts, duration, complete log path/hash, source/fixture/code hashes, and the bounded result summary.

Before entering the next phase, publish and persist one checkpoint summary containing: phase status; core semantic and file counts; byte length and SHA256 for every phase artifact; every validation command with working directory and exit code; evidence/log paths and hashes; audit epoch and disposition status where applicable; remaining issues; and the explicit next-phase gate decision. Missing fields or a nonzero mandatory command blocks phase advancement.

At minimum, local focused verification must exercise the new tests plus these affected baselines when their source modules change:

```powershell
npm run test:bmad-speckit -- goal-contract-source-obligation-extractor.test.js goal-contract-source-normative-blocks.test.js goal-contract-source-execution-semantics.test.js goal-contract-real-source-plan.test.js goal-contract-canonical-control-plane.test.js goal-contract-implementation-proof.test.js goal-contract-partition-compiler.test.js
npm exec --offline -- vitest run tests/acceptance/goal-execution-contract-generator-skill-contract.test.ts tests/acceptance/req-trace-main-agent-dispatch-integration.test.ts tests/acceptance/main-agent-state-matrix-authority.test.ts
npm run build:main-agent-dist
node _bmad/skills/encoding-integrity-guardian/scripts/check-encoding-integrity.js
git diff --check
```

### 6.3 Progress state

| Phase | Initial state | Completion evidence |
| --- | --- | --- |
| 1. BUGFIX authority | `complete` | promoted target hash plus latest-hash audit PASS |
| 2. Source contract | `complete` | template/profile/lint and install-surface GREEN; phase 2 checkpoint recorded |
| 3. Minimal fixtures | `complete` | canonical 12-node/50-relation fixture, nine exact-class negative fixtures, and production standalone structured IR assertions GREEN; Phase 3 checkpoint recorded |
| 4. Full derivation | `complete` | canonical full source `sha256:d0aa0be0d8773e8029724c2dd4027578bfdf614870c93332cc082fb54890f74a` with 2,506 mapped source spans and zero unmapped spans |
| 5. Proof assets | `complete` | manifest/expected/integrity checks GREEN; fixture review confirmed; portable `-05` confirmed authority fixture has 22 hash-verified files and production confirm-scope returns `confirmation_reused` |
| 6. Compiler TDD | `in_progress` | confirmed-authority adapter and canonical normalization focused tests GREEN; three-entry compile/closure/projection parity and same-SHA remote CI remain open |

Update this table only with real evidence. Do not mark later phases complete retroactively in one batch.

### 6.4 Delivery and release

After Phase 6, compare actual tracked and staged paths with Section 6.1. Commit only approved files using the repository commit convention. Push the final repair to `dev`, ensure regular CI and nightly-full both pass against the exact same final SHA, then merge the open `dev` to `master` PR.

Run the repository's authoritative npm release workflow in dry-run mode before publication. Publish `v2.2.1` with Trusted Publishing only after the dry-run and merged-master evidence pass. Verify npm registry version, `latest` dist-tag, Git tag, GitHub Release, release assets, commit SHA, and provenance. Do not publish the same version twice.

### 6.5 Stop conditions

Stop only for a required unresolved source decision, a directly conflicting user change, missing destructive/remote authorization, unavailable credentials or external service with persisted failure evidence, or a material blocker that remains after the governed review/repair limits. Compiler difficulty, test failures, document size, or the need for additional bounded investigation are not blockers.
